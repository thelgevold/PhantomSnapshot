﻿/*
The MIT License (MIT)

Copyright (c) 2013 Torgeir Helgevold

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.
 */

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Text;
using System.Web;
using System.Web.Mvc;

namespace SnapshotJSClient.Controllers
{
    public class DemoController : Controller
    {
        public ActionResult DownloadJpegFromUrl(ConvertionModel model)
        {
            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("http://localhost:8080");

            ASCIIEncoding encoding = new ASCIIEncoding();
            string postData = string.Format("url={0}&format=jpeg",model.UrlToConvertJpeg);
            byte[] data = encoding.GetBytes(postData);

            httpWReq.Method = "POST";
            httpWReq.ContentType = "application/x-www-form-urlencoded";
            httpWReq.ContentLength = data.Length;

            using (Stream stream = httpWReq.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            var response = (HttpWebResponse)httpWReq.GetResponse();

            Response.AppendHeader("Content-Disposition", "attachment;filename=test.jpg");

            using(StreamReader sr = new StreamReader(response.GetResponseStream()))
            {
                var bytes = System.Convert.FromBase64String(sr.ReadToEnd());
                return File(bytes, "image/jpeg");
            }
        }

        public ActionResult DownloadPngFromUrl(ConvertionModel model)
        {
            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("http://localhost:8080");

            ASCIIEncoding encoding = new ASCIIEncoding();
            string postData = string.Format("url={0}&format=png",model.UrlToConvertPng);
            byte[] data = encoding.GetBytes(postData);

            httpWReq.Method = "POST";
            httpWReq.ContentType = "application/x-www-form-urlencoded";
            httpWReq.ContentLength = data.Length;

            using (Stream stream = httpWReq.GetRequestStream())
            {
                stream.Write(data, 0, data.Length);
            }
            
            var response = (HttpWebResponse)httpWReq.GetResponse();

            Response.AppendHeader("Content-Disposition", "attachment;filename=test.png");

            using (StreamReader sr = new StreamReader(response.GetResponseStream()))
            {
                var bytes = System.Convert.FromBase64String(sr.ReadToEnd());
                return File(bytes, "image/png");
            }
        }

        public ActionResult DownloadPdfFromUrl(ConvertionModel model)
        {
            HttpWebRequest httpWReq = (HttpWebRequest)WebRequest.Create("http://localhost:8080");

            ASCIIEncoding encoding = new ASCIIEncoding();
            string postData = string.Format("url={0}&fileName=myTest&extension=pdf&format=pdf", model.UrlToConvertPdf);
            byte[] data = encoding.GetBytes(postData);

            httpWReq.Method = "POST";
            httpWReq.ContentType = "application/x-www-form-urlencoded";
            httpWReq.ContentLength = data.Length;

            using (Stream s = httpWReq.GetRequestStream())
            {
                s.Write(data, 0, data.Length);
            }

            var response = (HttpWebResponse)httpWReq.GetResponse();

            Response.AppendHeader("Content-Disposition", "attachment;filename=test.pdf");
           
            return new FileStreamResult(response.GetResponseStream(), "application/pdf");
        }

        public ActionResult Index()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

    }
}
